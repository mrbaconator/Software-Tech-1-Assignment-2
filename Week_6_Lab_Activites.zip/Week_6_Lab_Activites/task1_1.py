#loading an image
import matplotlib.pyplot as plt
from keras.preprocessing.image import load_img

img_path = '/content/1_Gammar 2021_1_2021_06_03-13-19-23-856.PNG'
img = load_img(img_path)

print(type(img))
print(img.format)
print(img.mode)
print(img.size)

plt.imshow(img)
plt.axis('off') # Turn off axis labels
plt.show()
